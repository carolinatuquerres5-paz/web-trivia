
function cargarPregunta(0) {
    let objetoPregunta = baseDePreguntas[js]
    document.getElementById("prgunta").innerHTML = objetoPregunta.baseDePreguntas

}